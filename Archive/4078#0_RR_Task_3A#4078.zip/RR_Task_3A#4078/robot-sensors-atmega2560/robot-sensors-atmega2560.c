/*
 * TITLE: robot-sensors-atmega2560.c
 * DATE: 
 * AUTHOR: Mayank Singhal
 */ 


/*
TODO:
*Use names instead of Pin numbers in DDR and PORT for motors initialization
*Refactor
*Use a global var or define to store addresses of sensors i.e 0x30 0x32 0x34
*One function to initialise all sensors
*/
#define F_CPU 16000000

#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "i2c.h"
#include "VL53L0X.h"
#include "uart.h"


//Motor setup

float duty_cycle(float dc){
    // Find OCR for given duty cycle
    // dc in percent
    dc = dc/100;
    return 255-255*dc;
}


void set_motor_duty_cycle(int motor_number, float dc){
    if (motor_number==1){
        // OCR5AL = (int) duty_cycle(dc);
        OCR0A = (int) duty_cycle(dc);
    }
    else{
        // OCR5CL = (int) duty_cycle(dc);
        OCR5BL = (int) duty_cycle(dc);
    }
}


void init_motor(){
	// Setup timers for motors
    // Setup timers at 0A 5B
    cli();

	DDRL |= ((1<<PL3) | (1<<PL4) | (1<<PL5));
	DDRB |= (1<<PB7);

	PORTL &= ~((1<<PL3) | (1<<PL4) | (1<<PL5));
	PORTB &= ~(1<<PB7);

    // TCCR5A = 0x00;
    TCCR5B = 0x00;
    // TCCR5C = 0x00;
    TCCR0A = 0x00;

    TCNT5H = 0x00;
    TCNT5L = 0x00;
    // TCNT0H = 0xFF;
    // TCNT0L = 0x00;

    // OCR5AH = 0xFF;
    // OCR5AL = 0x00;
    OCR5BH = 0x00;
    OCR5BL = 0x00;
    // OCR5CH = 0xFF;
    // OCR5CL = 0x00;
    OCR0A = 0x00;

    //A register can be used to setup Compare Output Mode (COM)
    //and Wave Generation Mode (WGM) for register A, B, C
    // A1=1 A0=0 clear on match
    // A1=1 A0=1 set on match
    //5A, 5C same & 0A,5B same
    // one setup for one set opposite for another

    // 5A, 5C COMnA1=1, COMnA0=0
    // TCCR5A |= ((1<<COM5A1) | (1<<COM5C1));
    // TCCR5A &= ~((1<<COM5A0) | (1<<COM5C0));

    // 5B COMnA1=1, COMnA0=1
    TCCR5A |= ((1<<COM5B1) | (1<<COM5B0));
    // 0A COMnA1=1, COMnA0=1
    TCCR0A |= ((1<<COM0A1) | (1<<COM0A0));

    // Set Phase correct mode
    // WGM3, WGM2, WGM1, WGM0 = 0, 0, 0, 1 For 16bit reg i.e TCCR5
    // WGM2..0 same as above for 8bit i.e TCCR0

    TCCR5A |= 1<<WGM50;
    TCCR5A &= ~(1<<WGM51);
    TCCR5B &= ~((1<<WGM53) | (1<<WGM52));

    TCCR0A |= 1<<WGM00;
    TCCR0A &= ~(1<<WGM01);
    TCCR0B &= ~(1<<WGM02);

    // Prescalar to 64, just to be safe
    TCCR5B |= ((1<<CS51) | (1<<CS50));
    TCCR5B &= ~(1<<CS52);
    TCCR0B |= ((1<<CS01) | (1<<CS00));
    TCCR0B &= ~(1<<CS02);

    sei();

	set_motor_duty_cycle(1,0);
	set_motor_duty_cycle(2,0);

}



//Motor setup ends

uint16_t read_sensor(int num){

		if (num==1){
			select(0x30);
		}
		else if (num==2){
			select(0x32);
		}
		else if (num==3){
			select(0x34);
		}

		return readRangeSingleMillimeters(0);

}

void init_uart(){

	i2c_init();
	uart0_init(UART_BAUD_SELECT(115200, F_CPU));
	uart0_flush();

}

//VL53L0X sensors
void init_sensors(){
	int ret;
	int temp;
	bool io_2v8 = 1;

	// Set pins as output pins
	DDRA |= (1<<PA1) | (1<<PA3) | (1<<PA5);

	// xshut all sensors
	// awake when xshut=1
	PORTA = (0<<PA1) | (0<<PA3) | (0<<PA5);

	// Wake sensor at PA1
	PORTA |= (1<<PA1);
	select(0x52);
	ret = initVL53L0X(io_2v8);
	if (ret==1){
		// uart0_puts("\nInitialised device 1");
	}
	else{
		uart0_puts("\nUnable to inititalise device 1");
	}
	setAddress(0x30);
	_delay_ms(10);


	// Wake sensor at PA3
	PORTA |= (1<<PA3);
	select(0x52);
	ret=initVL53L0X(io_2v8);
	if (ret==1){
		// uart0_puts("\nInitialised device 2");
	}
	else{
		uart0_puts("\nUnable to inititalise device 2");
	}
	setAddress(0x32);
	_delay_ms(10);


	// Wake sensor at PA5
	PORTA |= (1<<PA5);
	select(0x52);
	ret = initVL53L0X(io_2v8);
	if (ret==1){
		// uart0_puts("\nInitialised device 3");
	}
	else{
		uart0_puts("\nUnable to inititalise device 3");
	}
	setAddress(0x34);
	_delay_ms(10);


}

void move_motors_avoid_walls(int start_flag){
	const int allowance = 10; // Change in mm after which duty cycle is changed
	// const int duty_cycle_mod = 20; // Value by which duty cycle is modified
	int sensor_num = 1;
	int motor_num = 1;
	const int motor_slow = 35;
	const int motor_fast = 70;
	// const uint16_t reference_reading = 40;
	static uint16_t reference_reading;
	static int duty_cycle = 50;
	uint16_t new_reading;

	if (start_flag == 1){
		set_motor_duty_cycle(1, duty_cycle);
		set_motor_duty_cycle(2, duty_cycle);
		reference_reading = read_sensor(sensor_num);
	}

	new_reading = read_sensor(sensor_num);

	// Do not use without int16_t, -ve value of unsigned (uint16_t) will go haywire
	if (reference_reading > new_reading){
		if ((reference_reading - new_reading) > allowance){
			set_motor_duty_cycle(motor_num, motor_fast);
		}
		else{
			set_motor_duty_cycle(motor_num, duty_cycle);
		}
	}

	else {// (new_reading > reference_reading)
		if ((new_reading - reference_reading) > allowance){
			set_motor_duty_cycle(motor_num, motor_slow);
		}
		else{
			set_motor_duty_cycle(motor_num, duty_cycle);
		}
	}

}

// use getc to get complete string from uart
char uart0_readByte(void){
	char t[100];
	uint16_t rx;
	uint8_t rx_status, rx_data;

	rx = uart0_getc();
	rx_status = (uint8_t)(rx >> 8);
	rx = rx << 8;
	rx_data = (uint8_t)(rx >> 8);

	if(rx_status == 0 && rx_data != 0){
		return rx_data;
	} else {
		return -1;
	}


}
int uart0_gets(char *rx_string){
	char ret;
	int rx_counter  = 0;
	while((ret = uart0_readByte()) != -1){	
			rx_string[rx_counter++] = ret;
	}

	if (rx_counter==0){
		return -1;
	}
	else{
		rx_string[rx_counter] = '\0';
		return rx_counter;
	}

}

int main(void) {

	uint16_t r1,r2,r3;
	uint8_t a1;
	char t[100];
	int start_flag=0;
	char rx[100];

	//Initialise everything
	init_uart();
	init_sensors();
	init_motor();

	while(1){

		uart0_gets(rx);

		if (strcmp(rx, "#tof#") == 0){
			r1 = read_sensor(1);
			r2 = read_sensor(2);
			r3 = read_sensor(3);
			sprintf(t, "@{tof1:%d,tof2:%d,tof3:%d}@", r1,r2,r3);
			uart_puts(t);
		}
		else if (strcmp(rx, "#start#") == 0){
			init_motor();
			start_flag = 1;
			move_motors_avoid_walls(1);
		}
		else if (strcmp(rx, "#stop#") == 0){
			start_flag = 0;
			set_motor_duty_cycle(1,0);
			set_motor_duty_cycle(2,0);
		}

		if (start_flag == 1){
			move_motors_avoid_walls(0);
		}
		else{
			set_motor_duty_cycle(1,0);
			set_motor_duty_cycle(2,0);
		}

		//Clear rx after Receiving
		rx[0] = '\0';

		_delay_ms(50);
	}

	return 0;
}