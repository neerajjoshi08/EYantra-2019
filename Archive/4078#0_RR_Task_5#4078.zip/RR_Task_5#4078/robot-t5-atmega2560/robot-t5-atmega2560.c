/*
 * TITLE: robot-t4-atmega2560.c
 * DATE: 
 * AUTHOR: Mayank Singhal
 */ 

#define F_CPU 16000000

#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
// #include <time.h>
#include "i2c.h"
#include "VL53L0X.h"
#include "uart.h"
#include "mcp23017.h"


// Constants for better readability
enum direction {LEFT, RIGHT, FRONT, BACK};

struct pos{
	int x;
	int y;
} cur, next;

enum direction facing = FRONT;

char shortest_path[200], digits[20], combination[100];

//Motor setup

float duty_cycle(float dc){
    // Find OCR for given duty cycle
    // dc in percent
    dc = dc/100;
    return 255-255*dc;
}


void set_motor_duty_cycle(int motor, float dc){

	if (dc >= 0){
		if (motor == RIGHT){
			OCR5AL = (int) duty_cycle(dc);
			OCR5CL = (int) duty_cycle(0);
		}
		else{
			OCR3AL = (int) duty_cycle(dc);
			OCR1AL = (int) duty_cycle(0);
		}
	}
	else {
		if (motor == RIGHT){
			OCR5AL = (int) duty_cycle(0);
			OCR5CL = (int) duty_cycle(fabs(dc));
		}
		else{
			OCR3AL = (int) duty_cycle(0);
			OCR1AL = (int) duty_cycle(fabs(dc));
		}
	}
}


void init_motor(){

	// Setup timers for motors
	// Setup timers at 5A-3A
	// Const at 1A-5C

	//PL5 == 5C
	//PL3 == 5A
	//PB5 == 1A
	//PE3 == 3A
    cli();

	DDRE |= (1<<PE3);
	DDRB |= (1<<PB5);
	DDRL |= ((1<<PL3) | (1<<PL5));

	PORTE &= ~(1<<PE3);
	PORTB &= ~(1<<PB5);
	PORTL &= ~((1<<PL3) | (1<<PL5));

    // TCCR5C = 0x00;
    TCCR1A = 0x00;
    TCCR5A = 0x00;
    TCCR3A = 0x00;

    TCNT5H = 0x00;
    TCNT5L = 0x00;
    TCNT1H = 0x00;
    TCNT1L = 0x00;
    TCNT3H = 0x00;
    TCNT3L = 0x00;

    OCR5AH = 0x00;
    OCR5AL = 0x00;

    OCR3AH = 0x00;
    OCR3AL = 0x00;

    OCR1AH = 0x00;
    OCR1AL = 0x00;

    OCR5CH = 0x00;
    OCR5CL = 0x00;


    //A register can be used to setup Compare Output Mode (COM)
    //and Wave Generation Mode (WGM) for register A, B, C
    // A1=1 A0=0 clear on match
    // A1=1 A0=1 set on match
    // 5A, 3A same & 5C, 1A same

    TCCR5A |= ((1<<COM5A1) | (1<<COM5A0) | (1<<COM5C1) | (1<<COM5C0));
    TCCR3A |= ((1<<COM3A1) | (1<<COM3A0));

    // TCCR5C |= ((1<<COM5C1) | (1<<COM5C0));
    TCCR1A |= ((1<<COM1A1) | (1<<COM1A0));


    // Set Phase correct mode
    // WGM3, WGM2, WGM1, WGM0 = 0, 0, 0, 1 For 16bit reg i.e TCCR5
    // WGM2..0 same as above for 8bit i.e TCCR0

    TCCR5A |= 1<<WGM50;
    TCCR5A &= ~(1<<WGM51);
    TCCR5B &= ~((1<<WGM53) | (1<<WGM52));

    TCCR3A |= 1<<WGM30;
    TCCR3A &= ~(1<<WGM31);
    TCCR3B &= ~((1<<WGM33) | (1<<WGM32));


    TCCR1A |= 1<<WGM10;
    TCCR1A &= ~(1<<WGM11);
    TCCR1B &= ~((1<<WGM13) | (1<<WGM12));

    // Prescalar to 64, just to be safe
    TCCR5B |= ((1<<CS51) | (1<<CS50));
    TCCR5B &= ~(1<<CS52);
    TCCR3B |= ((1<<CS31) | (1<<CS30));
    TCCR3B &= ~(1<<CS32);
	TCCR1B |= ((1<<CS11) | (1<<CS10));
    TCCR1B &= ~(1<<CS12);

    sei();

	set_motor_duty_cycle(LEFT,0);
	set_motor_duty_cycle(RIGHT,0);

}

//Motor setup ends


uint16_t read_sensor(int dir){

		int16_t offset;
		if (dir == LEFT){
			select(0x30);
			offset = -34;
		}
		else if (dir == FRONT){
			select(0x32);
			offset = -30;
		}
		else if (dir == RIGHT){
			select(0x34);
			offset = -33;
		}

		return offset + (int16_t) readRangeSingleMillimeters(0);

}

void init_uart(){

	i2c_init();
	uart0_init(UART_BAUD_SELECT(115200, F_CPU));
	uart0_flush();

}

//VL53L0X sensors
void init_sensors(){
	int ret;
	int temp;
	bool io_2v8 = 1;

	// Set pins as output pins
	DDRA |= (1<<PA1) | (1<<PA3) | (1<<PA5);

	// xshut all sensors
	// awake when xshut=1
	PORTA = (0<<PA1) | (0<<PA3) | (0<<PA5);

	// Wake sensor at PA1
	PORTA |= (1<<PA1);
	select(0x52);
	ret = initVL53L0X(io_2v8);
	if (ret==1){
		// uart0_puts("\nInitialised device 1");
	}
	else{
		uart0_puts("\nUnable to inititalise device 1");
	}
	setAddress(0x30);
	_delay_ms(10);


	// Wake sensor at PA3
	PORTA |= (1<<PA3);
	select(0x52);
	ret=initVL53L0X(io_2v8);
	if (ret==1){
		// uart0_puts("\nInitialised device 2");
	}
	else{
		uart0_puts("\nUnable to inititalise device 2");
	}
	setAddress(0x32);
	_delay_ms(10);


	// Wake sensor at PA5
	PORTA |= (1<<PA5);
	select(0x52);
	ret = initVL53L0X(io_2v8);
	if (ret==1){
		// uart0_puts("\nInitialised device 3");
	}
	else{
		uart0_puts("\nUnable to inititalise device 3");
	}
	setAddress(0x34);
	_delay_ms(10);


}

void init_LFA(){
	mcp23017_init();
	mcp23017_setmodeA(0, MCP23017_MODEINPUTALL);
	mcp23017_setmodepinB(0, 0, MCP23017_MODEOUTPUT);
	mcp23017_setmodepinB(0, 1, MCP23017_MODEOUTPUT);
	mcp23017_writepinB(0, 0, MCP23017_PINSTATEOFF);
	mcp23017_writepinB(0, 1, MCP23017_PINSTATEOFF);
}

void move_motors_avoid_walls(int start_flag){
	const int allowance = 10; // Change in mm after which duty cycle is changed
	// const int duty_cycle_mod = 20; // Value by which duty cycle is modified
	int sensor_num = LEFT;
	const int motor_slow = 35;
	const int motor_fast = 70;
	// const uint16_t reference_reading = 40;
	static uint16_t reference_reading = 0;
	static int duty_cycle = 50;
	static float kp = 0.2;
	uint16_t new_reading;

	if (start_flag == 1){ // Should run when new run is started without rebooting bot
		set_motor_duty_cycle(LEFT, duty_cycle);
		set_motor_duty_cycle(RIGHT, duty_cycle);
		reference_reading = read_sensor(LEFT);
	}

	if (reference_reading == 0){
		reference_reading = read_sensor(LEFT);
		set_motor_duty_cycle(LEFT, duty_cycle);
		set_motor_duty_cycle(RIGHT, duty_cycle);
	}


	new_reading = read_sensor(LEFT);
	set_motor_duty_cycle(LEFT, duty_cycle + kp*(reference_reading-new_reading));

}

// To check if 2 readings are nearby
int nearby(uint16_t a, uint16_t b){
	if (a > b){
		if((a-b) > 10){ // change is greater than 1cm==10mm
			return 0;
		}
		else{
			return 1;
		}
	}
	else{
		if ((b-a) > 10){
			return 0;
		}
		else{
			return 1;
		}
	}
}

void move_motors_turn(int direction){
	// int nearest_wall = 200;
	char tmp[100];
	int turning_dc = 35;
	uint16_t left_reading, front_reading, right_reading;

	left_reading = read_sensor(LEFT);
	front_reading = read_sensor(FRONT);
	right_reading = read_sensor(RIGHT);


	if (direction == LEFT){
		while(!( (nearby(read_sensor(FRONT), left_reading)) && (nearby(read_sensor(RIGHT), front_reading)) )){
			set_motor_duty_cycle(LEFT, -turning_dc);
			set_motor_duty_cycle(RIGHT, turning_dc);
			_delay_ms(500);
			set_motor_duty_cycle(LEFT, 0);
			set_motor_duty_cycle(RIGHT, 0);
			_delay_ms(500);
		}
		set_motor_duty_cycle(LEFT, 0);
		set_motor_duty_cycle(RIGHT, 0);
	}
	
	else if (direction == RIGHT){
		while(!( (nearby(read_sensor(FRONT), right_reading)) && (nearby(read_sensor(LEFT), front_reading)) )){
			set_motor_duty_cycle(RIGHT, -turning_dc);
			set_motor_duty_cycle(LEFT, turning_dc);
			_delay_ms(500);
			set_motor_duty_cycle(LEFT, 0);
			set_motor_duty_cycle(RIGHT, 0);
			_delay_ms(500);
		}
		set_motor_duty_cycle(LEFT, 0);
		set_motor_duty_cycle(RIGHT, 0);
	}
	
}

// use getc to get complete string from uart
char uart0_readByte(void){
	char t[100];
	uint16_t rx;
	uint8_t rx_status, rx_data;

	rx = uart0_getc();
	rx_status = (uint8_t)(rx >> 8);
	rx = rx << 8;
	rx_data = (uint8_t)(rx >> 8);

	if(rx_status == 0 && rx_data != 0){
		return rx_data;
	} else {
		return -1;
	}


}
int uart0_gets(char *rx_string){
	char ret;
	int rx_counter  = 0;
	while((ret = uart0_readByte()) != -1){	
			rx_string[rx_counter++] = ret;
	}

	if (rx_counter==0){
		return -1;
	}
	else{
		rx_string[rx_counter] = '\0';
		return rx_counter;
	}

}

enum direction get_next_direction(){
	// directions according to what robot
	// would see when started at 4,4
	enum direction next_dir;

	if (facing == FRONT){
		if (next.y > cur.y){
			next_dir = FRONT;
		}
		else if (next.y < cur.y){
			next_dir = BACK;
			facing = BACK;
		}
		else{
			if (next.x > cur.x){
				next_dir = RIGHT;
				facing = RIGHT;
			}
			else if (next.x < cur.x){
				next_dir = LEFT;
				facing = LEFT;
			}
		}
		return next_dir;
	}

	if (facing == RIGHT){
		if (next.y > cur.y){
			next_dir = LEFT;
			facing = FRONT;
		}
		else if (next.y < cur.y){
			next_dir = RIGHT;
			facing = BACK;
		}
		else{
			if (next.x > cur.x){
				next_dir = FRONT;
				facing = RIGHT;
			}
			else if (next.x < cur.x){
				next_dir = BACK;
				facing = LEFT;
			}
		}

		return next_dir;
	}

	if (facing == LEFT){
		if (next.y > cur.y){
			next_dir = RIGHT;
			facing = FRONT;
		}
		else if (next.y < cur.y){
			next_dir = LEFT;
			facing = BACK;
		}
		else{
			if (next.x > cur.x){
				next_dir = BACK;
				facing = RIGHT;
			}
			else if (next.x < cur.x){
				next_dir = FRONT;
				facing = LEFT;
			}
		}

		return next_dir;
	}

	if (facing == BACK){
		if (next.y > cur.y){
			next_dir = BACK;
			facing = FRONT;
		}
		else if (next.y < cur.y){
			next_dir = FRONT;
			facing = BACK;
		}
		else{
			if (next.x > cur.x){
				next_dir = LEFT;
				facing = RIGHT;
			}
			else if (next.x < cur.x){
				next_dir = RIGHT;
				facing = LEFT;
			}
		}
		return next_dir;
	}

}

int black_line(){

	if (mcp23017_readpinsA(0) > 0)
		return 1;
	else
		return 0;
	
}

int find_and_report_firezone(struct pos next){
	char msg[50];
	char victims = '0';
	size_t path_len = strlen(shortest_path); 

	if ((next.x == 9) && (next.y == 9)){
		return 2;
	}
	else if(( next.x == shortest_path[path_len-7]) && (next.y == shortest_path[path_len-4])){
		// Last coordinate on path, hence firezone
		PORTH &= ~(1<<PH3);
		_delay_ms(1000);
		PORTH |= 1<< PH3;
 
		for(int i=0; i<strlen(combination); i++){
		
				if(combination[i] == ':'){
						victims = combination[i-1];
				}
				if((combination[i] == next.x) && (combination[i+3] == next.y)){
					break;
				}
		
		}

		sprintf(msg, "@$|%c|(%d,%d)@", victims, next.x, next.y);
		uart0_puts(msg);
	}
	else{
		return 0;
	}

}

void get_next_position(){
	//[(1, 2), (3, 4), (5, 6), (7, 8)]
	for(int i=0; i<strlen(shortest_path); i++){
		if((shortest_path[i] == '(') && ((int)(shortest_path[i+1] - '0') == cur.x) && ((int)(shortest_path[i+4]-'0')==cur.y)){
			next.x = (int) (shortest_path[i+9] - '0');
			next.y = (int) (shortest_path[i+12] - '0');
		}
	}
}

int main(void) {

	uint16_t r1,r2,r3, peek_var;
	uint8_t a1, lfa_reading;
	char t[100], hosp='A';
	int start_flag=0, start_run=0, start_lf, temp;
	char rx[100];
	// clock_t clock_time;
	double time_to_traverse_half_cell = 0;
	enum direction next_dir;

	//Initialise everything
	init_uart();
	init_sensors();
	init_motor();
	init_LFA();
	//PE7 == USER_SW
	DDRE &= ~(1<<PE7);
	// Red LED, Green LED 
	DDRH |= (1<<PH3) | (1<<PH5);
	PORTH |= (1<<PH3) | (1<<PH5);

	while(1){
		if (start_flag == 0){
			set_motor_duty_cycle(LEFT, 0);
			set_motor_duty_cycle(RIGHT, 0);
			uart0_gets(digits);
			if(strlen(digits)==0){
				continue;
			}
			_delay_ms(10);
			uart0_gets(combination);
			_delay_ms(10);
			uart0_gets(shortest_path);
			_delay_ms(10);

			cur.x = 4;
			cur.y = 4;
			facing = FRONT;

			start_flag = 1; // Execution started
		}

		// Reposition
		peek_var = uart0_peek();
		if ( peek_var == '&' ){
			uart0_gets(shortest_path);
			start_run = 2;
			uart0_flush();
		}
		// Restart
		else if ( peek_var == '%'){
			start_run == 2;
			start_flag = 0;
			uart0_flush();
			continue;
		}
		if (!(PINE & (1<<PE7))){ // USER_SW pressed
			_delay_ms(100);
			if (start_run == 0)
				uart0_puts("\n@started@");
			start_run = 1; // Run started (Traversal)
			//start run
		}

		if (start_run == 1){
			next_dir = get_next_direction();
			if (next_dir == FRONT){
				if (time_to_traverse_half_cell == 0){
					while(!black_line()){
						move_motors_avoid_walls(0);
					}
					time_to_traverse_half_cell = 1; // second
					move_motors_avoid_walls(0);
					temp = time_to_traverse_half_cell;
					while(temp){
						_delay_ms(1000);
						temp--;
					}
					set_motor_duty_cycle(LEFT, 0);
					set_motor_duty_cycle(RIGHT, 0);
				}
				else {
					move_motors_avoid_walls(0);
					time_to_traverse_half_cell = 1;
					temp = time_to_traverse_half_cell;
					while(temp){
						_delay_ms(2*1000);
						temp--;
					}
					set_motor_duty_cycle(LEFT, 0);
					set_motor_duty_cycle(RIGHT, 0);
				}
			}
			else{
				move_motors_turn(next_dir);
				if (!find_and_report_firezone(next)){  // if firezone next. Put on led, and return that data within this func.
					move_motors_avoid_walls(0);
					temp = time_to_traverse_half_cell;
					while(temp){
						_delay_ms(2*1000);
						temp--;
					}
					set_motor_duty_cycle(LEFT, 0);
					set_motor_duty_cycle(RIGHT, 0);
				}

				else if(find_and_report_firezone(next) == 1){
					uart0_gets(shortest_path);
				}

				else{
					start_lf = 1;
					start_run = 0;
				}

			}
			
			cur = next;
			get_next_position();

		}

		if (start_lf){

			if (mcp23017_readpinsA(0) == 0b11111111){
				move_motors_turn(RIGHT);
			}
			else if(mcp23017_readpinsA(0) == 0b00011000){
				set_motor_duty_cycle(LEFT, 60);
				set_motor_duty_cycle(RIGHT, 60);
			}
			else if (mcp23017_readpinsA(0) > 0b00011000){
				set_motor_duty_cycle(LEFT, 30);
			}
			else if (mcp23017_readpinsA(0) < 0b00011000){
				set_motor_duty_cycle(RIGHT, 30);
			}
			else if (mcp23017_readpinsA(0) == 0b00000000){
				set_motor_duty_cycle(LEFT, 0);
				set_motor_duty_cycle(RIGHT, 0);
				PORTH &= ~(1<<PH5);
				_delay_ms(1000);
				PORTH |= 1<<PH5;
				sprintf(t, "@H%c reached", hosp++);
				if (hosp == 'C'){
					strcat(t, ", Task accomplished!@");
					uart0_puts(t);
				}
				else{
					strcat(t, "@");
				}
				uart0_puts(t);
				while(mcp23017_readpinsA(0)!= 0b00000000){
					set_motor_duty_cycle(LEFT, -50);
					set_motor_duty_cycle(RIGHT, -50);
				}
			}
		}

		//Clear rx after Receiving
		rx[0] = '\0';

		_delay_ms(50);
	}

	return 0;
}